// Service worker : ouverture instantanée et application installable (PC + Android)
const CACHE = 'babalfkamah-v4';
const SHELL = ['/', '/index.html', '/css/app.css', '/js/i18n.js', '/js/clavier.js', '/js/core.js', '/js/pos.js', '/js/vues.js', '/js/admin.js', '/vendor/webauthn.js', '/icons/icon-192.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.pathname.startsWith('/api/')) return; // données toujours en direct
  e.respondWith(fetch(e.request).then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return res; })
    .catch(() => caches.match(e.request).then(r => r || caches.match('/index.html'))));
});
